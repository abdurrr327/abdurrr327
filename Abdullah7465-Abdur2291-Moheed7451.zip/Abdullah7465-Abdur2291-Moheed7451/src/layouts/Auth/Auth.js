import React, { useContext } from "react";
import { Route, Routes, Navigate } from "react-router-dom";

import routes from "routes.js";

import { BackgroundColorContext } from "contexts/BackgroundColorContext";

function Auth(props) {
  const mainPanelRef = React.useRef(null);

  const { color } = useContext(BackgroundColorContext);

  const getRoutes = (routes) => {
    return routes.map((prop, key) => {
      if (prop.layout === "/auth") {
        return (
          <Route path={prop.path} element={prop.component} key={key} exact />
        );
      } else {
        return null;
      }
    });
  };

  return (
    <React.Fragment>
      <div className="wrapper">
        <div className="main-panel" ref={mainPanelRef} data={color}>
          <Routes>
            {getRoutes(routes)}
            <Route path="/" element={<Navigate to="/auth/login" replace />} />
          </Routes>
        </div>
      </div>
    </React.Fragment>
  );
}

export default Auth;
