import React, { useContext } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { AuthContext } from "contexts/AuthContext";

import AdminLayout from "layouts/Admin/Admin.js";
import AuthLayout from "layouts/Auth/Auth.js";

export default function App() {
  const { isAuthenticated } = useContext(AuthContext);

  return (
    <Routes>
      {isAuthenticated ? (
        <Route path="/admin/*" element={<AdminLayout />} />
      ) : (
        <Route path="/auth/*" element={<AuthLayout />} />
      )}
      {/* Redirect any other paths to appropriate initial screen */}
      <Route
        path="*"
        element={
          <Navigate
            to={isAuthenticated ? "/admin/dashboard" : "/auth/login"}
            replace
          />
        }
      />
    </Routes>
  );
}
