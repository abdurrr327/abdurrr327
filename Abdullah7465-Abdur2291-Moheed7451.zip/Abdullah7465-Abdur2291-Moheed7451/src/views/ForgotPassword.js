import React from "react";
import { useNavigate } from "react-router-dom";

// reactstrap components
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  CardText,
  FormGroup,
  Form,
  Input,
  Row,
  Col,
} from "reactstrap";

function ForgetPassword() {
  const navigate = useNavigate();

  const navigateTo = (path) => {
    navigate(path);
  };
  return (
    <>
      <div className="container">
        <Row className="vh-100 align-items-center justify-content-center">
          <Col md="4">
            <Card className="card-user">
              <CardBody>
                <CardText />
                <div className="author">
                  <div className="block block-one" />
                  <div className="block block-two" />
                  <div className="block block-three" />
                  <div className="block block-four" />
                  <a href="#pablo" onClick={(e) => e.preventDefault()}>
                    <h3 className="title">Forgot Password</h3>
                  </a>
                  <p className="card-description">Enter the registered email</p>
                </div>
                <Form style={{ marginTop: 30 }}>
                  <Row>
                    <Col md="12">
                      <FormGroup>
                        <label>Email</label>
                        <Input
                          defaultValue=""
                          placeholder="Enter Email"
                          type="email"
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                </Form>
              </CardBody>
              <CardFooter
                className="card-footer d-flex flex-column align-items-center"
                style={{ paddingTop: 0 }}
              >
                <Button
                  className="btn-fill"
                  color="primary"
                  type="submit"
                  style={{ width: "100%", marginBottom: "10px", marginTop: 0 }}
                  onClick={() => {
                    navigateTo("/auth/reset-password");
                  }}
                >
                  Continue
                </Button>
                <div
                  className="text-center mb-2"
                  style={{
                    fontSize: "0.8rem",
                    paddingTop: 5,
                    paddingBottom: 5,
                  }}
                >
                  <span>
                    Go back to?{" "}
                    <a
                      href="#reset"
                      onClick={() => {
                        navigateTo("/auth/login");
                      }}
                      style={{ color: "#e14eca", textDecoration: "underline" }}
                    >
                      Sign In
                    </a>
                  </span>
                </div>
              </CardFooter>
            </Card>
          </Col>
        </Row>
      </div>
    </>
  );
}

export default ForgetPassword;
