import React, { useState } from "react";

// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  Table,
  Row,
  Col,
  Input,
  Button,
} from "reactstrap";
import { FaPlus, FaEdit, FaTrash } from "react-icons/fa"; // Importing icons

function Expenses() {
  const [searchTerm, setSearchTerm] = useState("");

  const expenses = [
    {
      purpose: "Office Supplies",
      description: "Purchase of notebooks and pens",
      amount: 45.99,
      date: "2024-10-01",
      time: "10:30 AM",
    },
    {
      purpose: "Marketing",
      description: "Facebook Ads campaign",
      amount: 150.0,
      date: "2024-10-05",
      time: "2:00 PM",
    },
    {
      purpose: "Travel",
      description: "Business trip to conference",
      amount: 350.5,
      date: "2024-10-10",
      time: "8:00 AM",
    },
    {
      purpose: "Software Subscription",
      description: "Monthly subscription for project management tool",
      amount: 29.99,
      date: "2024-10-15",
      time: "11:15 AM",
    },
    {
      purpose: "Lunch with Client",
      description: "Lunch meeting with prospective client",
      amount: 75.0,
      date: "2024-10-20",
      time: "12:30 PM",
    },
    {
      purpose: "Utilities",
      description: "Electricity bill for the office",
      amount: 120.0,
      date: "2024-10-25",
      time: "9:00 AM",
    },
  ];

  // Function to handle search
  const filteredExpenses = expenses.filter((expense) =>
    expense.purpose.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="content">
      <Row>
        <Col md="12">
          <Card>
            <CardHeader>
              <Row>
                <Col md="8">
                  <Input
                    type="text"
                    placeholder="Search..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    style={{ marginBottom: "10px" }}
                  />
                </Col>
                <Col md="4" className="text-right">
                  <Button color="primary">
                    <FaPlus />
                  </Button>
                </Col>
              </Row>
            </CardHeader>
            <CardBody>
              <Table className="tablesorter" responsive>
                <thead className="text-primary">
                  <tr>
                    <th className="text-center">Purpose</th>
                    <th className="text-center">Description</th>
                    <th className="text-center">Amount</th>
                    <th className="text-center">Date</th>
                    <th className="text-center">Time</th>
                    <th className="text-center">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredExpenses.map((expense, index) => (
                    <tr key={index}>
                      <td className="text-center">{expense.purpose}</td>
                      <td className="text-center">{expense.description}</td>
                      <td className="text-center">{expense.amount}</td>
                      <td className="text-center">{expense.date}</td>
                      <td className="text-center">{expense.time}</td>
                      <td className="text-center">
                        <Button color="warning" size="sm" className="mr-2">
                          <FaEdit />
                        </Button>
                        <Button color="danger" size="sm">
                          <FaTrash />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  );
}

export default Expenses;
