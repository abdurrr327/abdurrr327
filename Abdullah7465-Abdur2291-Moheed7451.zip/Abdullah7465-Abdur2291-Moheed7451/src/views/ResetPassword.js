import React from "react";
import { useNavigate } from "react-router-dom";

// reactstrap components
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  CardText,
  FormGroup,
  Form,
  Input,
  Row,
  Col,
} from "reactstrap";

function ResetPassword() {
  const navigate = useNavigate();

  const navigateTo = (path) => {
    navigate(path);
  };
  return (
    <>
      <div className="container">
        <Row className="vh-100 align-items-center justify-content-center">
          <Col md="4">
            <Card className="card-user">
              <CardBody>
                <CardText />
                <div className="author">
                  <div className="block block-one" />
                  <div className="block block-two" />
                  <div className="block block-three" />
                  <div className="block block-four" />
                  <a href="#pablo" onClick={(e) => e.preventDefault()}>
                    <h3 className="title">Reset Password</h3>
                  </a>
                  <p className="card-description">
                    Enter the following credentials
                  </p>
                </div>
                <Form style={{ marginTop: 30 }}>
                  <Row>
                    <Col md="12">
                      <FormGroup>
                        <label>Code</label>
                        <Input
                          defaultValue=""
                          placeholder="Enter Verification Code"
                          type="number"
                        />
                      </FormGroup>
                    </Col>
                  </Row>

                  <Row>
                    <Col md="12">
                      <FormGroup>
                        <label>Password</label>
                        <Input
                          defaultValue=""
                          placeholder="Enter Password"
                          type="password"
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col md="12">
                      <FormGroup>
                        <label>Confirm Password</label>
                        <Input
                          defaultValue=""
                          placeholder="Enter Confirmation Password"
                          type="password"
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                </Form>
              </CardBody>
              <CardFooter
                className="card-footer d-flex flex-column align-items-center"
                style={{ paddingTop: 0 }}
              >
                <Button
                  className="btn-fill"
                  color="primary"
                  type="submit"
                  style={{ width: "100%", marginBottom: "10px", marginTop: 0 }}
                  onClick={() => {
                    navigateTo("/auth/login");
                  }}
                >
                  Reset
                </Button>

                <div
                  className="text-center"
                  style={{ fontSize: "0.7rem", paddingBottom: 5 }}
                >
                  <span>
                    Want to go back?{" "}
                    <a
                      href="#signup"
                      onClick={() => {
                        navigateTo("/auth/forgot-password");
                      }}
                      style={{
                        color: "#e14eca",
                        textDecoration: "underline",
                        cursor: "pointer",
                      }}
                    >
                      Click here
                    </a>
                  </span>
                </div>
              </CardFooter>
            </Card>
          </Col>
        </Row>
      </div>
    </>
  );
}

export default ResetPassword;
