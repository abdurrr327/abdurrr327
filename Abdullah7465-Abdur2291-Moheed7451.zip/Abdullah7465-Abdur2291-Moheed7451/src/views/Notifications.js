import React from "react";
// react plugin for creating notifications over the dashboard
import NotificationAlert from "react-notification-alert";

// reactstrap components
import {
  Alert,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Row,
  Col,
} from "reactstrap";

function Notifications() {
  const notificationAlertRef = React.useRef(null);

  return (
    <>
      <div className="content">
        <div className="react-notification-alert-container">
          <NotificationAlert ref={notificationAlertRef} />
        </div>
        <Row>
          <Col md="4">
            <Card>
              <CardHeader>
                <CardTitle tag="h4">Notifications Title</CardTitle>
              </CardHeader>
              <CardBody>
                <Alert color="info">
                  <span>Description</span>
                </Alert>
              </CardBody>
            </Card>
          </Col>
          <Col md="4">
            <Card>
              <CardHeader>
                <CardTitle tag="h4">Notifications Title</CardTitle>
              </CardHeader>
              <CardBody>
                <Alert color="info">
                  <span>Description</span>
                </Alert>
              </CardBody>
            </Card>
          </Col>
          <Col md="4">
            <Card>
              <CardHeader>
                <CardTitle tag="h4">Notifications Title</CardTitle>
              </CardHeader>
              <CardBody>
                <Alert color="info">
                  <span>Description</span>
                </Alert>
              </CardBody>
            </Card>
          </Col>
        </Row>
        <Row>
          <Col md="4">
            <Card>
              <CardHeader>
                <CardTitle tag="h4">Notifications Title</CardTitle>
              </CardHeader>
              <CardBody>
                <Alert color="info">
                  <span>Description</span>
                </Alert>
              </CardBody>
            </Card>
          </Col>
          <Col md="4">
            <Card>
              <CardHeader>
                <CardTitle tag="h4">Notifications Title</CardTitle>
              </CardHeader>
              <CardBody>
                <Alert color="info">
                  <span>Description</span>
                </Alert>
              </CardBody>
            </Card>
          </Col>
          <Col md="4">
            <Card>
              <CardHeader>
                <CardTitle tag="h4">Notifications Title</CardTitle>
              </CardHeader>
              <CardBody>
                <Alert color="info">
                  <span>Description</span>
                </Alert>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    </>
  );
}

export default Notifications;
