import React, { useState } from "react";

// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  Table,
  Row,
  Col,
  Input,
  Button,
} from "reactstrap";
import { FaPlus, FaEdit, FaTrash } from "react-icons/fa"; // Importing icons

function Distributors() {
  const [searchTerm, setSearchTerm] = useState("");

  const distributors = [
    {
      name: "Distributor 1",
      phone: "555-0101",
      email: "dist1@example.com",
      category: "Category A",
      balance: 15000,
    },
    {
      name: "Distributor 2",
      phone: "555-0102",
      email: "dist2@example.com",
      category: "Category B",
      balance: 23000,
    },
    {
      name: "Distributor 3",
      phone: "555-0103",
      email: "dist3@example.com",
      category: "Category C",
      balance: 35000,
    },
    {
      name: "Distributor 4",
      phone: "555-0104",
      email: "dist4@example.com",
      category: "Category D",
      balance: 28000,
    },
    {
      name: "Distributor 5",
      phone: "555-0105",
      email: "dist5@example.com",
      category: "Category E",
      balance: 41000,
    },
    {
      name: "Distributor 6",
      phone: "555-0106",
      email: "dist6@example.com",
      category: "Category F",
      balance: 12000,
    },
    {
      name: "Distributor 7",
      phone: "555-0107",
      email: "dist7@example.com",
      category: "Category G",
      balance: 17000,
    },
  ];

  // Function to handle search
  const filteredDistributors = distributors.filter((distributor) =>
    distributor.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="content">
      <Row>
        <Col md="12">
          <Card>
            <CardHeader>
              <Row>
                <Col md="8">
                  <Input
                    type="text"
                    placeholder="Search..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    style={{ marginBottom: "10px" }}
                  />
                </Col>
                <Col md="4" className="text-right">
                  <Button color="primary">
                    <FaPlus />
                  </Button>
                </Col>
              </Row>
            </CardHeader>
            <CardBody>
              <Table className="tablesorter" responsive>
                <thead className="text-primary">
                  <tr>
                    <th className="text-center">Name</th>
                    <th className="text-center">Phone</th>
                    <th className="text-center">Email</th>
                    <th className="text-center">Category</th>
                    <th className="text-center">Balance</th>
                    <th className="text-center">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredDistributors.map((distributor, index) => (
                    <tr key={index}>
                      <td className="text-center">{distributor.name}</td>
                      <td className="text-center">{distributor.phone}</td>
                      <td className="text-center">{distributor.email}</td>
                      <td className="text-center">{distributor.category}</td>
                      <td className="text-center">{distributor.balance}</td>
                      <td className="text-center">
                        <Button color="warning" size="sm" className="mr-2">
                          <FaEdit />
                        </Button>
                        <Button color="danger" size="sm">
                          <FaTrash />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  );
}

export default Distributors;
