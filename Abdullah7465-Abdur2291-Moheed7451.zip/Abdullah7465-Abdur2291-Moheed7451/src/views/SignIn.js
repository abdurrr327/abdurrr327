import { AuthContext } from "contexts/AuthContext";
import React, { useContext } from "react";
import { useNavigate } from "react-router-dom";

// reactstrap components
import {
  Button,
  Card,
  CardBody,
  CardFooter,
  CardText,
  FormGroup,
  Form,
  Input,
  Row,
  Col,
} from "reactstrap";

function SignIn() {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const navigateTo = (path) => {
    navigate(path);
  };
  return (
    <>
      <div className="container">
        <Row className="vh-100 align-items-center justify-content-center">
          <Col md="4">
            <Card className="card-user">
              <CardBody>
                <CardText />
                <div className="author">
                  <div className="block block-one" />
                  <div className="block block-two" />
                  <div className="block block-three" />
                  <div className="block block-four" />
                  <a href="#pablo" onClick={(e) => e.preventDefault()}>
                    <h3 className="title">Welcome</h3>
                  </a>
                  <p className="card-description">
                    Enter the following credentials
                  </p>
                </div>
                <Form style={{ marginTop: 30 }}>
                  <Row>
                    <Col md="12">
                      <FormGroup>
                        <label>Email</label>
                        <Input
                          defaultValue=""
                          placeholder="Enter Email"
                          type="email"
                        />
                      </FormGroup>
                    </Col>
                  </Row>

                  <Row>
                    <Col md="12">
                      <FormGroup>
                        <label>Password</label>
                        <Input
                          defaultValue=""
                          placeholder="Enter Password"
                          type="password" // changed to 'password' for security
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                </Form>
              </CardBody>
              <CardFooter
                className="card-footer d-flex flex-column align-items-center"
                style={{ paddingTop: 0 }}
              >
                <Button
                  className="btn-fill"
                  color="primary"
                  type="submit"
                  style={{ width: "100%", marginBottom: "10px", marginTop: 0 }}
                  onClick={() => {
                    login("abc");
                  }}
                >
                  Sign In
                </Button>
                <div
                  className="text-center mb-2"
                  style={{
                    fontSize: "0.8rem",
                    paddingTop: 5,
                    paddingBottom: 5,
                  }}
                >
                  <span>
                    Forgot your password?{" "}
                    <a
                      href="#reset"
                      onClick={() => {
                        navigateTo("/auth/forgot-password");
                      }}
                      style={{
                        color: "#e14eca",
                        textDecoration: "underline",
                        cursor: "pointer",
                      }}
                    >
                      Reset here
                    </a>
                  </span>
                </div>
                <div
                  className="text-center"
                  style={{ fontSize: "0.7rem", paddingBottom: 5 }}
                >
                  <span>
                    Already have an account?{" "}
                    <a
                      href="#signup"
                      onClick={() => {
                        navigateTo("/auth/register");
                      }}
                      style={{
                        color: "#e14eca",
                        textDecoration: "underline",
                        cursor: "pointer",
                      }}
                    >
                      Sign up
                    </a>
                  </span>
                </div>
              </CardFooter>
            </Card>
          </Col>
        </Row>
      </div>
    </>
  );
}

export default SignIn;
