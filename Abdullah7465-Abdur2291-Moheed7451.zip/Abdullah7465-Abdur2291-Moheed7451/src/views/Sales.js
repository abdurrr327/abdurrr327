import React, { useState } from "react";

// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  Table,
  Row,
  Col,
  Input,
  Button,
} from "reactstrap";
import { FaPlus, FaEdit, FaTrash, FaInfoCircle } from "react-icons/fa"; // Importing icons

function Sales() {
  const [searchTerm, setSearchTerm] = useState("");

  const sales = [
    {
      sellOrderId: 201,
      title: "Sell to Customer - 1",
      amount: 100,
      date: "2024-01-15",
      time: "10:30 AM",
    },
    {
      sellOrderId: 202,
      title: "Sell to Customer - 2",
      amount: 200,
      date: "2024-02-10",
      time: "11:00 AM",
    },
    {
      sellOrderId: 203,
      title: "Sell to Customer - 3",
      amount: 150,
      date: "2024-03-20",
      time: "02:15 PM",
    },
    {
      sellOrderId: 204,
      title: "Sell to Customer - 4",
      amount: 300,
      date: "2024-04-05",
      time: "09:45 AM",
    },
    {
      sellOrderId: 205,
      title: "Sell to Customer - 5",
      amount: 250,
      date: "2024-05-12",
      time: "03:00 PM",
    },
    {
      sellOrderId: 206,
      title: "Sell to Customer - 6",
      amount: 400,
      date: "2024-06-30",
      time: "01:30 PM",
    },
    {
      sellOrderId: 207,
      title: "Sell to Customer - 7",
      amount: 350,
      date: "2024-07-18",
      time: "04:20 PM",
    },
  ];

  // Function to handle search
  const filteredSales = sales.filter((sale) =>
    sale.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="content">
      <Row>
        <Col md="12">
          <Card>
            <CardHeader>
              <Row>
                <Col md="8">
                  <Input
                    type="text"
                    placeholder="Search..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    style={{ marginBottom: "10px" }}
                  />
                </Col>
                <Col md="4" className="text-right">
                  <Button color="primary">
                    <FaPlus />
                  </Button>
                </Col>
              </Row>
            </CardHeader>
            <CardBody>
              <Table className="tablesorter" responsive>
                <thead className="text-primary">
                  <tr>
                    <th className="text-center">OrderId</th>
                    <th className="text-center">Title</th>
                    <th className="text-center">Amount</th>
                    <th className="text-center">Date</th>
                    <th className="text-center">Time</th>
                    <th className="text-center">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredSales.map((sale, index) => (
                    <tr key={index}>
                      <td className="text-center">{sale.sellOrderId}</td>
                      <td className="text-center">{sale.title}</td>
                      <td className="text-center">{sale.amount}</td>
                      <td className="text-center">{sale.date}</td>
                      <td className="text-center">{sale.time}</td>
                      <td className="text-center">
                        <Button color="warning" size="sm" className="mr-2">
                          <FaInfoCircle />
                        </Button>
                        <Button color="warning" size="sm" className="mr-2">
                          <FaEdit />
                        </Button>
                        <Button color="danger" size="sm">
                          <FaTrash />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  );
}

export default Sales;
