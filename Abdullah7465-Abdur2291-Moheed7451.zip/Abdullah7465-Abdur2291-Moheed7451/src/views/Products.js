import React, { useState } from "react";

// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  Table,
  Row,
  Col,
  Input,
  Button,
} from "reactstrap";
import { FaPlus, FaEdit, FaTrash } from "react-icons/fa"; // Importing icons

function Products() {
  const [searchTerm, setSearchTerm] = useState("");

  const products = [
    { name: "Product 1", type: "Type A", price: "$36,738", quantity: 10 },
    { name: "Product 2", type: "Type B", price: "$23,789", quantity: 15 },
    { name: "Product 3", type: "Type C", price: "$56,142", quantity: 5 },
    { name: "Product 4", type: "Type D", price: "$38,735", quantity: 8 },
    { name: "Product 5", type: "Type E", price: "$63,542", quantity: 12 },
    { name: "Product 6", type: "Type F", price: "$78,615", quantity: 7 },
    { name: "Product 7", type: "Type G", price: "$98,615", quantity: 3 },
  ];

  // Function to handle search
  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="content">
      <Row>
        <Col md="12">
          <Card>
            <CardHeader>
              <Row>
                <Col md="8">
                  <Input
                    type="text"
                    placeholder="Search..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    style={{ marginBottom: "10px" }}
                  />
                </Col>
                <Col md="4" className="text-right">
                  <Button color="primary">
                    <FaPlus />
                  </Button>
                </Col>
              </Row>
            </CardHeader>
            <CardBody>
              <Table className="tablesorter" responsive>
                <thead className="text-primary">
                  <tr>
                    <th className="text-center">Name</th>
                    <th className="text-center">Type</th>
                    <th className="text-center">Price</th>
                    <th className="text-center">Quantity</th>
                    <th className="text-center">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map((product, index) => (
                    <tr key={index}>
                      <td className="text-center">{product.name}</td>
                      <td className="text-center">{product.type}</td>
                      <td className="text-center">{product.price}</td>
                      <td className="text-center">{product.quantity}</td>
                      <td className="text-center">
                        <Button color="warning" size="sm" className="mr-2">
                          <FaEdit />
                        </Button>
                        <Button color="danger" size="sm">
                          <FaTrash />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  );
}

export default Products;
